package myhangmangame;

/**
 * A simple Hangman application written in Java.
 * @author Md Ashik
 */
public class MyHangmanGame
{
    public static void main(String[] args) 
    {
        GameBoard newHangmanGame = new GameBoard();
    }
}

 